questCON — Stranger Things CTF

Flag format: questCON{<part1>-<part2>-<part3>}

You will find three folders: stage1, stage2, stage3.
- stage1: ECDSA signature artifacts (public key + signatures). Look for nonce leakage / lattice attacks.
- stage2: 624 MT19937 outputs + AES-encrypted blob. Reconstruct MT state to derive AES key.
- stage3: many AES-CTR ciphertexts reusing a nonce + hint image (LSB). Recover keystream slice and crib-drag.

Hints are in publish/hints (if present). Do NOT expect solver code or private keys in the package.
